<html>
<head>
<title>Welcome to our side </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css2?family=Raleway:wght@300;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

<link type="text/css" href="css/style.css" rel="stylesheet">

  
</head>
<body>
<header>
	<nav class="navbar navbar-expand-lg navbar-light">
  <a class="navbar-brand" href="#">HeathBuddy</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
          <a class="nav-link" href="doctor_appointment.php">Doctor appointment</a> <span class="sr-only">(current)</span>
      </li>
      <li class="nav-item">
          <a class="nav-link" href="contact.php">About Us</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="Doctor.php">Doctors</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Pages
        </a>
       <div class="dropdown-menu" aria-labelledby="navbarDropdown">
         <ul class="dropdown-item">
                    <li><a href="#">Supplements</a></li>
                    <li class="has-children">
                      <a href="#">Vitamins</a>
                      <ul class="dropdown-item">
                        <li><a href="#">Supplements</a></li>
                        <li><a href="#">Vitamins</a></li>
                        <li><a href="#">Diet &amp; Nutrition</a></li>
                        <li><a href="#">Tea &amp; Coffee</a></li>
                      </ul> 
         
        </div>
      </li>

      
              
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown_1">
              
               </div>
               </li>
               <li class="nav-item">
                <a class="nav-link" href="contact.html"></a>
                </li>
                </ul>
                </div>
          <a class="btn_2 d-none d-lg-block" href="tel:1122">HOT LINE-1122</a>
  </div>
</nav>
<div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/rsz_2pharmacy.jpg" alt="Los Angeles" width="1100" height="500">
      <div class="carousel-caption">
        <h3>Medicine Centre</h3>
        <p>Medicines and health products are important for addressing health problems and improve quality of lives
        </p>
      </div>   
    </div>
    
    <div class="carousel-item">
      <img src="images/rsz_hero_1.jpg" alt="New York" width="1100" height="500">
      <div class="carousel-caption">
        <h3>Necessary medicine</h3>
        <p>We provide any kind of medicines that you want!</p>
    </div>   
    </div>

  </div>
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>

</header>

<section>
<div class="container-fluid">
	<h1 class="text-center text-capitalize pt-5"> about us </h1>
	<hr class="w-25 mx-auto pb-5">

	<div class="row mb-5">
		<div class="col-lg-6 col-md-6 col-12">
			<img src="images/checkup.jpg" class="img-fluid">
		</div>

		<div class="col-lg-6 col-md-6 col-12">
			<h1>Who We Are?</h1>
			<hr>
			<p>Every person needs a doctor for their health checkup. In their busy lives, they often forget to
             make an appointment with the doctor and miss their regular health checkup Specially now in corona time, health checkup have become much more important for all people.
             We can help them to make appointments for themselves even they are in rush. They can easily fill in details and choose an appointment near their locations. And they also   get the medicine and necessities according to their needs in corona time.</p>
                        <button class="btn bg-dark text-white"><a href="doctor_appointment.php">Make an Appointment</a></button>
        </div>
    </div> 
</div>



    <div class="site-section">
      <div class="container">
        <div class="row">
          <div class="title-section text-center col-12">
            <h2 class="text-uppercase">Popular Products</h2>
          </div>
        </div>

        <div class="row">
            <div class="col-sm-6 col-lg-4 text-center item mb-4">
            <a href="shop-single.html"> <img src="images/product-1.png" alt="Image"></a>
            <h3 class="text-dark"><a href="shop-single.html">Savlon Active</a></h3>
            <p class="price">BDT.30</p>
          </div>
          <div class="col-sm-6 col-lg-4 text-center item mb-4">
            <a href="shop-single.html"> <img src="images/product-2.png" alt="Image"></a>
            <h3 class="text-dark"><a href="shop-single.html">Masks-50 pieces</a></h3>
            <p class="price">BDT.250.00</p>
          </div>
          <div class="col-sm-6 col-lg-4 text-center item mb-4">
            <a href="shop-single.html"> <img src="images/product-3.png" alt="Image"></a>
            <h3 class="text-dark"><a href="shop-single.html">Dabur Hand Senitizer-500ml</a></h3>
            <p class="price"><del>BDT.480.00</del> &mdash; 380.00</p>
          </div>

          <div class="col-sm-6 col-lg-4 text-center item mb-4">

            <a href="shop-single.html"> <img src="images/product-4.png" alt="Image"></a>
            <h3 class="text-dark"><a href="shop-single.html">Lifebouy Handwash-500ml</a></h3>
            <p class="price"><del>BDT.145.00</del> &mdash; 100.00</p>
          </div>
          <div class="col-sm-6 col-lg-4 text-center item mb-4">
            <a href="shop-single.html"> <img src="images/product-5.png" alt="Image"></a>
            <h3 class="text-dark"><a href="shop-single.html">Hand Gloves</a></h3>
            <p class="price">BDT.100.00</p>
          </div>
          <div class="col-sm-6 col-lg-4 text-center item mb-4">
            <a href="shop-single.html"> <img src="images/product-6.png" alt="Image"></a>
            <h3 class="text-dark"><a href="shop-single.html">Paracetamol Tablets</a></h3>
            <p class="price">BDT.200.00</p>
          </div>
          
        </div>
        
       

</section>
       



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js">
  </script>
   <footer>
     
      <a href="" id="#top" target=""> go to top ⬆</a>
      <p> Author: Simran Sharmin Joarder & Mishkat chowdhury </p>
      <a href="mailto:simran35-2407@diu.edu.bd,janntul35-2409@diu.edu.bd">contact:simran35-2407@diu.edu.bd,jannatul35-2409@diu.edu.bd</a>
      &copy; All rights reserved

     
  </footer>

</body>
</html>