

<html>
    <head>
        <title>Appointment</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link type="text/css" href="css/style.appoinment.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
       
    </head>
    <body>
       <section class="my-5">
        <div class="py-5">
        	<h2 class= "text-center">Make an Appointment</h2>
        	  
        </div> 
           <div>
           <div class="w-50 m-auto">
               <form action="make_appoinment.php" method="post">
                                   
                                <div class="form-group">
                                    <label>UserName</label>
                                    <input type="text" name="full_name" autocomplete="off" class="form-group">
                                </div>
                                <div class="form-group">
                                    <label>Email Address</label>
                                    <input type="text" name="email_address" autocomplete="off" class="form-group">
                                </div>
                                <div class="form-group">
                                    <label>Phone Number</label>
                                    <input type="text" name="mobile_number" autocomplete="off" class="form-group">
                                </div>
                                
                                <div class="form-group">
                                        <label>Time</label>
                                        <select name="time" class="form-control" id="Select2">
                                        <option value="1">Select a time</option>
                                        <option value="8 AM TO 10AM">8 AM TO 10AM</option>
                                        <option value="10 AM TO 12PM">10 AM TO 12PM</option>
                                        <option value="12PM TO 2PM">12PM TO 2PM</option>
                                        <option value="2PM TO 4PM">2PM TO 4PM</option>
                                        <option value="4PM TO 6PM">4PM TO 6PM</option>
                                        <option value="6PM TO 8PM">6PM TO 8PM</option>
                                        <option value="4PM TO 10PM">4PM TO 10PM</option>
                                        <option value="10PM TO 12PM">10PM TO 12PM</option>
                                    </select>
                                </div>
                                
                            </div>
               <div id="appoinment_wrapper">
                   <button class="btn bg-dark text-white">Make an Appointment</button>
                   
                   
               </div>
                        </form>
               
               <div id="phone">
                   <h1>Contact With Us</h1>
                   <i class="fa fa-phone" style="font-size:36px"></i>
                
                <br>

<p>01786440156,01621215249</p>
</div>
                    </div>
           </div>
                </div>
                
                    
                
            </div>
        </div>
</section>



    </body>
</html>
