<html>
    <head>
        <title>About  Us</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link type="text/css" href="css/contact_us.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
       
    </head>
    <body>
        <div>
            <div id="main_wrapper">
                
                <h2>Our Recent Work<div id="our_work"><p>A one-stop solution for pharmacy application and website
                            development bundled with expert pharmacy marketing. We provide comprehensive 
                            B2B and B2C online pharmacy solutions. We are enabling pharmacy shop owners to 
                            utilize technology adoption with mobile app and website development for their business
                            and help them expand it even further. Our clients located in 35+ countries have been
                            relying on our high-end services for more than 10 years. </p></div></h2>
            </div>
            <div id="footer">
                
                <i class="fa fa-phone" style="font-size:36px"></i>
                
                <br>

<p>01786440156,01621215249</p>
            </div>
            
        </div>
    </body>
</html>


