<html>
    <head>
        <title>Doctor</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link type="text/css" href="css/doctors.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
       <div class="row">
  <div class="column">
      <h2>DR. ZIAUL KARIM
          <h5>Chest & Medicine Specialist
          Graduated from IPGMR (BSMMU) in 1987,
MCPS(Pediatric medicine) in 1992 June,

MPH (State university of Bangladesh)in 2004,
PhD (American World University-Bangladesh study centre)in Pediatric medicine in 2012,
worked in nibedita nursing home from 1988-1997, dhaka shishu hospital from 1991-1995,working as senior Pediatric consultant in nibedita Shishu Hospital from 1997 till today,
practicing as Pediatric Consultant in Gandaria (old dhaka)since 1992 till today.</h5></h2>
      <img src="images/DR.-ZIAUL-KARIM.jpg"  style="width:80%">
  </div>
  <div class="column">
       <h2>DR. FARZANA BANU
          <h5>gynae..
              Qualification: MBBS, FCPS
Designation: Consultant
Expertise: Gynae & Infertility
Organization:   Institute of Child and Mother Health (ICMH), Matuail, Dhaka-1362
Chamber: Saleha Diagnostic Centre
Address: London Market, Sanarpar, Demra, Dhaka.
Visiting Hours: 8pm-10pm (Saturday, Monday, Wednesday)
Phone for serial: 01715295950, 01913774554</h5></h2>
      <img src="images/Dr.-Farzana-Banu.jpg"  style="width:380px" height="360px">
  </div>
  <div class="column">
       <h2>DR. ZAHANGIR HOSSAIN
          <h5>Pediatrics
Graduated from IPGMR (BSMMU) in 1987,
MCPS(Pediatric medicine) in 1992 June,

MPH (State university of Bangladesh)in 2004,
PhD (American World University-Bangladesh study centre)in Pediatric medicine in 2012,
worked in nibedita nursing home from 1988-1997, dhaka shishu hospital from 1991-1995,working as senior Pediatric consultant in nibedita Shishu Hospital from 1997 till today,
practicing as Pediatric Consultant in Gandaria (old dhaka)since 1992 till today.</h5></h2>
      <img src="images/DR-Mahmud-Masum-Attar.jpg"  style="width:380px" height="358px">
  </div>
            
                  </div>
            <div id="footer">
                
                <i class="fa fa-phone" style="font-size:36px"></i>
                
                <br>

<p>01786440156,01621215249</p>
            </div>
                

</div>
</div>

    </body>
</html>


