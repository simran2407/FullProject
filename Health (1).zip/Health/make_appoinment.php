<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


$host_name='localhost';
$user_name='root';
$password='';
$db_name='db_health';


$conn=mysqli_connect($host_name,$user_name,$password,$db_name);

if(!$conn)
{
    die("Mysql Connection Errot");
}
else{
   // echo "Database Server connected successfully!";
}

$sql="INSERT INTO tbl_appoinment (name, email_address,mobile_number,time) VALUES ('$_POST[full_name]','$_POST[email_address]','$_POST[mobile_number]','$_POST[time]')";

mysqli_query($conn,$sql);
echo "Appoinment Created Successfully!";